
import os
import sqlite3
from functools import wraps
from flask import Flask, request, jsonify, session
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.secret_key = os.environ.get("PROFITZONE_SECRET")

if not app.secret_key:
    raise RuntimeError(
        "Set PROFITZONE_SECRET before starting the app."
    )

DB = os.path.join(os.path.dirname(__file__), "users.db")


def get_db():
    conn = sqlite3.connect(DB)
    conn.row_factory = sqlite3.Row
    return conn


with get_db() as db:
    db.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT NOT NULL COLLATE NOCASE UNIQUE,
            email TEXT NOT NULL COLLATE NOCASE UNIQUE,
            phone TEXT NOT NULL UNIQUE,
            password_hash TEXT NOT NULL,
            invitation_code TEXT DEFAULT '',
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        )
    """)


def login_required(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        if "user_id" not in session:
            return jsonify(error="Please log in first"), 401
        return fn(*args, **kwargs)
    return wrapper


@app.get("/")
def home():
    from flask import send_from_directory
    return send_from_directory(os.path.dirname(__file__), "login.html")

@app.post("/api/signup")
def signup():
    data = request.get_json(silent=True) or {}
    username = str(data.get("username", "")).strip()
    email = str(data.get("email", "")).strip()
    phone = str(data.get("phone", "")).strip()
    password = str(data.get("password", ""))
    invitation = str(data.get("invitation_code", "")).strip()

    if not all([username, email, phone, password]):
        return jsonify(error="All required fields must be filled"), 400
    if len(username) < 3 or len(username) > 30:
        return jsonify(error="Username must be 3-30 characters"), 400
    if len(password) < 10 or len(password) > 128:
        return jsonify(error="Password must be 10-128 characters"), 400
    if len(email) > 254 or "@" not in email:
        return jsonify(error="Enter a valid email"), 400
    if len(phone) > 30 or len(invitation) > 50:
        return jsonify(error="Input is too long"), 400

    try:
        with get_db() as db:
            cur = db.execute("""
                INSERT INTO users
                (username, email, phone, password_hash, invitation_code)
                VALUES (?, ?, ?, ?, ?)
            """, (
                username, email, phone,
                generate_password_hash(password), invitation
            ))
            user_id = cur.lastrowid
    except sqlite3.IntegrityError:
        return jsonify(error="Username, email or phone already registered"), 409

    session.clear()
    session["user_id"] = user_id
    return jsonify(message="Account created", username=username), 201


@app.post("/api/login")
def login():
    data = request.get_json(silent=True) or {}
    identity = str(data.get("identity", "")).strip()
    password = str(data.get("password", ""))

    with get_db() as db:
        user = db.execute("""
            SELECT * FROM users
            WHERE username = ? OR email = ? OR phone = ?
        """, (identity, identity, identity)).fetchone()

    if not user or not check_password_hash(user["password_hash"], password):
        return jsonify(error="Invalid login details"), 401

    session.clear()
    session["user_id"] = user["id"]
    return jsonify(message="Login successful", username=user["username"])


@app.get("/api/me")
@login_required
def me():
    with get_db() as db:
        user = db.execute(
            "SELECT username, email, phone FROM users WHERE id = ?",
            (session["user_id"],)
        ).fetchone()
    if not user:
        session.clear()
        return jsonify(error="Account not found"), 404
    return jsonify(dict(user))


@app.post("/api/logout")
def logout():
    session.clear()
    return jsonify(message="Logged out")


@app.get("/dashboard")
@login_required
def dashboard():
    from flask import send_from_directory
    return send_from_directory(os.path.dirname(__file__), "index.html")


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=False)


